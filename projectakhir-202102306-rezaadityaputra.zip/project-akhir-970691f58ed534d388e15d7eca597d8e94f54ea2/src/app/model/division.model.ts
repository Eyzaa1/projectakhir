export class Division {
    _id?:any;
    name?:string;
    description?:string;
}
